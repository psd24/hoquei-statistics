import { SeasonTeam } from './entities/SeasonTeam';
import { Season } from './entities/Season';
import { TeamMatch } from './entities/TeamMatch';
import { TeamPlayer } from './entities/TeamPlayer';
import { Team } from './entities/Team';
import { PlayerMatch } from './entities/PlayerMatch';
import { Match } from './entities/Match';
import { Club } from './entities/Club';
import { Position } from './entities/Position';
import { Role } from './entities/Role';
import { Player } from './entities/Player';
import { User } from './entities/User';
import { ConnectionOptions } from "typeorm";

const config: ConnectionOptions = {
    type: "mysql",
    host: "localhost",
    port: 3306,
    username: "root",
    password: "Ld@deol99",
    database: "e-club",
    //entities:[User,Player,Role,Position,Club,Match,PlayerMatch,Team,TeamPlayer,TeamMatch,Season,SeasonTeam],
    entities: [__dirname + '/**/*.entity{.ts,.js}'],
  
    // We are using migrations, synchronize should be set to false.
    synchronize: false,
  
    // Run migrations automatically,
    // you can disable this if you prefer running migration manually.
    migrationsRun: true,
    logging: true,
    logger: 'file',
  
    migrations: [__dirname + '/migration/**/*{.ts,.js}'],
    cli: {
      // Location of migration should be inside src folder
      // to be compiled into dist/ folder.
      migrationsDir: 'src/migration',
    }
  
}

export = config;