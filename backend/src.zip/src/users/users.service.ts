//import { Role } from './../../entities/Role';


// import { Player } from './../../entities/Player';
import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from 'src/entities/User';

import { Repository } from 'typeorm';
import { RegisterUserDto } from './dtos/register-user.dto';


@Injectable()
export class UsersService {
    private readonly users: User[];

    constructor(
        @InjectRepository(User)
        private readonly usersRepository: Repository<User>
        // @InjectRepository(Role)
        // private readonly rolesRepository: Repository<Role>,
        // @InjectRepository(Player)
        // private readonly playersRepository: Repository<Player>,
    ) {}

    async findByEmail(email: string): Promise<User | undefined> {
        return this.usersRepository.findOne({
          //  relations: ['role', 'player'],
            where: {
                email,
            },
        });
    }

    async register(userDto: RegisterUserDto): Promise<User> {
        const user = await this.findByEmail(userDto.email);
        if (user) {
            throw new BadRequestException('User already registered.');
        }

        const newUser = new User();
        newUser.userEmail = userDto.email;
        newUser.userName = userDto.name;
        newUser.userId = userDto.code;
        newUser.userPassword = userDto.password;

        // newUser.userRole = await this.rolesRepository.findOne({ id: userDto.role });
        // if (!newUser.userRole) {
        //     throw new BadRequestException('Invalid role id.');
        // }

        // newUser.userPlayer = await this.playersRepository.findOne({
        //     playerId: userDto.Player,
        // });
        // if (!newUser.userPlayer) {
        //     throw new BadRequestException('Invalid Player id.');
        // }
        return this.usersRepository.save(newUser);
    }

    // async addRoles(roleNames: string[]): Promise<Role[]> {
    //     return this.rolesRepository.save(roleNames.map(r => new Role(r)));
    // }

    // async addOrganizations(
    //     organizationNames: string[],
    // ): Promise<Player[]> {
    //     return this.playersRepository.save(
    //         organizationNames.map(o => new Player()),
    //     );
    // }

    // async roleCount(): Promise<number> {
    //     return this.rolesRepository.count();
    // }

    // async organizationsCount(): Promise<number> {
    //     return this.organizationsRepository.count();
    // }
}
